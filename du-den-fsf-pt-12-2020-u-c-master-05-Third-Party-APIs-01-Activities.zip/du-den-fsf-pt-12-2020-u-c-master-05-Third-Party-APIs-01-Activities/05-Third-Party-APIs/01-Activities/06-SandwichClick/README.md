### File

* [`sandwich-click-unsolved`](Unsolved/sandwich-click-unsolved.html)

### Instructions

* Add in the missing code such that clicking any of the sandwiches causes…

  1. An alert message to popup saying something snarky about the sandwich type.

  2. A second alert message that displays to the user how many of that specific sandwich they've eaten.

  3. **HINT:** You will need counter variables.

* **BONUS:** Add an image to the `image-div` on the click event.
