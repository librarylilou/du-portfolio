### File

* [`trigger-random-unsolved`](../07-TriggerRandom/Unsolved/trigger-random-unsolved.html)

### Instructions

* Using the code from the previous random number generator as a starting point, create a lottery generator.

  * In our case, the lottery number generator should pick 9 random numbers between 0-9 and output as one number. As an example: 886563264.

  * Display this number in the random-number div.

  * Then when a user clicks again, have the code create a new row with the latest number at the top.
