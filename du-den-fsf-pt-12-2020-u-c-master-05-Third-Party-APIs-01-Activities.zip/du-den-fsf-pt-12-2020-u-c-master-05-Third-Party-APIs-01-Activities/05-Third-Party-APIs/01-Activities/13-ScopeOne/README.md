# Scope Activity #1

## Instructions

* Open `Unsolved/index.html` in a browser and then open the console.

* With your neighbor, compare the results in the console to the JavaScript in `index.html` and answer the questions in the comments.

* **HINT**: Read the [MDN docs on closures](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Closures)
