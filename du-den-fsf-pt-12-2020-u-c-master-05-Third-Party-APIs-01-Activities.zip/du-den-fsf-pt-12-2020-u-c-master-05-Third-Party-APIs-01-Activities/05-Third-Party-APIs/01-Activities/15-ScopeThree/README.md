### File

* [`lexical-scope-3-unsolved`](Unsolved/lexical-scope-3-unsolved.html)

### Instructions

* Take a few moments to dissect the code in the file above.

* Try to predict what will be printed in each of the examples.

* Be prepared to share!
